"""Gate the full local batch on completed, independently verified smoke predictions."""
from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys
import time
import traceback

W=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(W/'work/PolymerBenchmark2026-main/Models'))
from shared_benchmark import load_split
import numpy as np
import pandas as pd
from sklearn.metrics import r2_score

OUT=W/'outputs/added_models'
STATUS=OUT/'execution_status.json'
LOCK=W/'work/new_model_logs/supervisor.lock'

def status(state,**extra):
    value=dict(status=state,updated_at=time.strftime('%Y-%m-%d %H:%M:%S %z'),pid=os.getpid(),**extra)
    stage=STATUS.with_suffix('.tmp');stage.write_text(json.dumps(value,indent=2)+'\n');stage.replace(STATUS)
    print(json.dumps(value),flush=True)

def verify(model,prop):
    root=W/'work/added_model_runs/smoke'/model
    r=json.loads((root/'metrics.json').read_text())
    if r['status']!='complete' or r['model']!=model or r['config']['epochs']!=1:
        raise ValueError('Smoke configuration mismatch')
    manifest=W/f'work/PolymerBenchmark2026-main/Datasets/scaling_indices/MD_5000/{prop}/homopolymer_{prop}/seed_42/manifest.json'
    b=load_split(manifest,0,300)
    if r['provenance']['canonical_sha256']!=b.canonical_sha256 or r['provenance']['indices_sha256']!=b.indices_sha256:
        raise ValueError('Smoke provenance mismatch')
    for split in ('train','val','test'):
        df=pd.read_csv(root/f'preds_{split}.csv');expected=getattr(b,split)
        assert np.array_equal(df.row_index,expected.row_index)
        assert np.allclose(df.y_true,expected.target,rtol=1e-12,atol=1e-12)
        assert np.isfinite(df.y_pred).all()
        mse=float(np.mean((df.y_true-df.y_pred)**2));r2=1-mse/float(np.var(df.y_true,ddof=0))
        assert np.isclose(r2,r2_score(df.y_true,df.y_pred),rtol=1e-10,atol=1e-12)
        assert np.isclose(r2,r['metrics'][split]['r2'],rtol=1e-9,atol=1e-10)
        assert np.isclose(np.sqrt(mse),r['metrics'][split]['rmse'],rtol=1e-9,atol=1e-10)
    return dict(model=model,status='smoke_verified',epochs=1,formal_benchmark=False)

def main():
    fd=os.open(LOCK,os.O_CREAT|os.O_EXCL|os.O_WRONLY);os.write(fd,str(os.getpid()).encode());os.close(fd)
    try:
        status('waiting_for_mmpolymer_smoke',formal_completed_runs=0,expected_formal_runs=290)
        deadline=time.monotonic()+6*3600
        while not (W/'work/added_model_runs/smoke/MMPolymer/metrics.json').exists():
            log=(W/'work/new_model_logs/mmpolymer_smoke.log').read_text(errors='replace')
            if 'Traceback (most recent call last)' in log:raise RuntimeError('MMPolymer smoke failed; see smoke log')
            if time.monotonic()>deadline:raise TimeoutError('Smoke gate timed out after six hours; batch not started')
            time.sleep(30)
        checks=[verify('UniMol2_84M','Cp'),verify('MMPolymer','Cv')]
        (OUT/'smoke_checks.json').write_text(json.dumps(checks,indent=2)+'\n')
        status('formal_batch_running',expected_formal_runs=290,smoke_checks=checks)
        with (W/'work/new_model_logs/added_batch.log').open('a') as log:
            subprocess.run(['/bin/sh',str(OUT/'run_local.sh')],stdout=log,stderr=subprocess.STDOUT,check=True)
        summary=json.loads((OUT/'results/status.json').read_text())
        if summary['completed_runs']!=290:raise RuntimeError('Batch exited without all 290 completions')
        status('complete',**summary)
    except BaseException as exc:
        status('failed',error=str(exc),traceback=traceback.format_exc())
        raise
    finally:LOCK.unlink()

if __name__=='__main__':main()
