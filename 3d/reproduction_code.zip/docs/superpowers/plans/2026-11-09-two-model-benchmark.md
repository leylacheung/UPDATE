# Two-model benchmark implementation plan

Approved scope: ../specs/2026-11-09-two-model-benchmark.md.
Execute continuously in this session; no commits from this ZIP checkout.

1. Shared split and evaluation contract (Models/shared_benchmark.py).
   First test published-index identity, tampered SHA rejection, invalid train
   size rejection, and R2/row count invariants in tests/test_shared_benchmark.py.
   Implement load_split and write_run as specified, run the tests.
2. Uni-Mol2 adapter (Models/UniMol2/train_scaling.py and README.md).
   Pin upstream revision; bypass automatic CV and global label scaling.
   Direct model/trainer uses explicit train/val, test inference only after
   checkpoint selection. Verify pretrained weight loading and endpoint policy.
3. MMPolymer adapter (Models/MMPolymer/train_scaling.py and README.md).
   Load official dual-modality checkpoint and original model implementation.
   Reuse official conformer/tokenizer conventions with row-preserving cache;
   allow documented CPU library compatibility changes only. Test missing
   weights fail and train/val separation; actual small-fold train verification.
4. Batch runner and collector (scripts/run_added_models.py and
   scripts/summarize_added_models.py). Iterate the public matrix, provenance-
   checked resume, log failures, write detailed/aggregate CSVs with R2 and
   completed-fold count. Never fill unrun conditions with old metrics.
5. Review, run repository checks, smoke-train both adapters, then run 290 jobs
   as resources allow. Deliver source additions and only measured outcomes;
   report external-weight/runtime blockers explicitly.

Progress ledger: work/new_model_logs/progress.md (workspace-relative).
