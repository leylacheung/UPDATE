# Approved Uni-Mol2 and MMPolymer benchmark

User approved on 2026-11-09: Uni-Mol2-84M and official pretrained MMPolymer,
full-parameter fine-tuning, maximum 50 epochs, original ten conditions / 29
condition-size pairs / five repeated splits, 290 added runs. Validation RMSE
selects the checkpoint; test labels never select settings or checkpoints.

Use exact canonical SHA-256 and published indices; train_pool[:N], val, test.
Preserve row_index through conformer generation and prediction. No silent row
filtering or internal random resplitting. Normalization fits train only.
Save predictions and compute RMSE and R2 = 1 - MSE / var(y, ddof=0), cross-check
against sklearn r2_score, aggregate mean and population SD across completed folds.
Partial runs remain clearly labeled. No reused published errors as new results.

Uni-Mol2 uses the official 84M architecture and checkpoint via unimol_tools.
MMPolymer uses both its original 1D and 3D pathways and official checkpoint.
Each model retains necessary molecular preprocessing; disclose how PSMILES
dummy endpoints are represented. CPU/full-float adaptation is allowed and must
be recorded. Do not silently replace fine-tuning with frozen embeddings or
random initialization. Missing weights are blocking for actual training.

Run sequentially on local CPU, benchmark one small fold before batching.
Preserve all earlier outputs; resumability requires provenance/config identity.
External source remains under work/new_model_sources; the benchmark directory
gets adapters, documentation and tests. Do not commit/upload; this is a ZIP
checkout, not a Git worktree. GPL source stays external with its attribution.

Shared API in Models/shared_benchmark.py:
load_split(manifest_path, fold, train_size) -> SplitBundle with train, val, test
DataFrames (row_index, smiles, target), target_column, manifest, canonical_sha256.
write_run(output_dir, model_name, bundle, predictions, config) -> metrics.json;
predictions maps train/val/test to 1D numpy arrays in input row order.

Validation: exact row identity and disjointness, positive supported sizes,
finite predictions, train-only scaling, metrics against sklearn, official-weight
loading checks and actual forward/backward on one small fold. Unsupported rows
or weight mismatch fail with a report instead of changing the evaluation set.
