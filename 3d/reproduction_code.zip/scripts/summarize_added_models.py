"""Recompute fold metrics from saved predictions; report incomplete coverage."""
import argparse
import json
from pathlib import Path
import sys
import numpy as np
import pandas as pd
from sklearn.metrics import r2_score
from run_added_models import build_jobs

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'Models'))
from shared_benchmark import load_split

def collect(root):
    rows=[];coverage=[]
    for j in build_jobs():
        path=root/j['key']/'metrics.json'
        coverage.append(dict(model=j['model'],experiment=j['experiment'],train_size=j['train_size'],fold=j['fold'],complete=path.is_file()))
        if not path.is_file():continue
        record=json.loads(path.read_text())
        for field in ('model','fold','train_size'):
            if record.get(field)!=j[field]:raise ValueError('Run identity mismatch: '+str(path))
        if record['status']!='complete' or record['config']['epochs']!=50:raise ValueError('Not a completed 50-epoch benchmark: '+str(path))
        bundle=load_split(j['manifest'],j['fold'],j['train_size'])
        if record['provenance']['canonical_sha256']!=bundle.canonical_sha256 or record['provenance']['indices_sha256']!=bundle.indices_sha256:
            raise ValueError('Data provenance mismatch: '+str(path))
        for split in ('train','val','test'):
            frame=pd.read_csv(path.parent/f'preds_{split}.csv');expected=getattr(bundle,split)
            if not np.array_equal(frame.row_index,expected.row_index) or not np.allclose(frame.y_true,expected.target,rtol=1e-12,atol=1e-12):
                raise ValueError('Prediction row/target mismatch: '+str(path))
            y=frame.y_true.to_numpy();pred=frame.y_pred.to_numpy()
            if not np.isfinite(pred).all():raise ValueError('Nonfinite prediction')
            mse=float(np.mean((y-pred)**2));variance=float(np.var(y,ddof=0));r2=1-mse/variance
            values=dict(rmse=float(np.sqrt(mse)),mse=mse,mae=float(np.mean(abs(y-pred))),r2=r2)
            if not np.isclose(r2,r2_score(y,pred),rtol=1e-10,atol=1e-12):raise ValueError('R2 crosscheck failed')
            if any(not np.isclose(v,record['metrics'][split][k],rtol=1e-9,atol=1e-10) for k,v in values.items()):raise ValueError('Stored metric mismatch')
            dataset,quantity,polymer=j['experiment'].split('/')
            rows.append(dict(model=j['model'],experiment=j['experiment'],dataset=dataset,quantity=quantity,
                polymer_type='alternating' if polymer.startswith('alternating') else 'homopolymer' if polymer.startswith('homopolymer') else polymer,
                train_size=j['train_size'],fold=j['fold'],split=split,**values,n_samples=len(y),target_variance=variance))
    return pd.DataFrame(rows),pd.DataFrame(coverage)

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--input',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
    detailed,coverage=collect(a.input);a.output.mkdir(parents=True,exist_ok=True)
    coverage.to_csv(a.output/'coverage.csv',index=False)
    if len(detailed):
        detailed.to_csv(a.output/'scaling_results_detailed.csv',index=False)
        keys=['experiment','dataset','quantity','polymer_type','model','train_size','split']
        grouped=detailed.groupby(keys,sort=True)
        aggregate=grouped.agg(**{f'{m}_{stat}':(m,'mean' if stat=='mean' else lambda x:x.std(ddof=0)) for m in ['rmse','r2','mse','mae'] for stat in ['mean','std']},completed_folds=('fold','nunique')).reset_index()
        aggregate['expected_folds']=5;aggregate['complete']=aggregate.completed_folds.eq(5)
        aggregate.to_csv(a.output/'scaling_results_aggregate.csv',index=False)
    status=dict(expected_runs=len(coverage),completed_runs=int(coverage.complete.sum()),remaining_runs=int((~coverage.complete).sum()),r2_aggregation='arithmetic mean of per-fold R2; std ddof=0; never derive from mean RMSE')
    (a.output/'status.json').write_text(json.dumps(status,indent=2)+'\n');print(json.dumps(status),flush=True)

if __name__=='__main__':main()
