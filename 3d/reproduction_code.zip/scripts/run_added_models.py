"""Sequential, resumable 290-run benchmark; no automatic split or row filtering."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

ROOT=Path(__file__).resolve().parents[1]

def digest(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        for chunk in iter(lambda:f.read(1024*1024),b''):h.update(chunk)
    return h.hexdigest()

def file_hashes(root,suffixes):
    root=Path(root).resolve()
    return {str(p.relative_to(root)):digest(p) for p in sorted(root.rglob('*'))
            if p.is_file() and p.suffix in suffixes and not any(x.startswith('.') for x in p.relative_to(root).parts)}

def build_jobs(root=ROOT):
    matrix=json.loads((root/'Datasets/dataset_manifest.json').read_text())['scaling_experiments']
    jobs=[]
    for e in matrix:
        experiment='/'.join([e['dataset'],e['property'],Path(e['file']).stem])
        manifest=root/'Datasets/scaling_indices'/experiment/'seed_42/manifest.json'
        for size in e['train_sizes']:
            for fold in range(5):
                for model in ('UniMol2_84M','MMPolymer'):
                    jobs.append(dict(key=f'{model}/{experiment}/train_{size}/fold_{fold:02d}',
                        model=model,experiment=experiment,manifest=manifest,train_size=size,fold=fold))
    # Start with smaller homopolymer jobs to obtain useful timing early.
    return sorted(jobs,key=lambda j:('homopolymer' not in j['experiment'],j['train_size'],j['experiment'],j['fold'],j['model']))

def check_resume(record,job,weight_sha,provenance,expected_config=None):
    for field in ('model','fold','train_size'):
        if record.get(field)!=job[field]:raise ValueError('Resume identity mismatch: '+field)
    if record.get('status')!='complete' or record.get('config',{}).get('epochs')!=50:
        raise ValueError('Only completed 50-epoch runs may be resumed')
    if record['config'].get('checkpoint_sha256')!=weight_sha:
        raise ValueError('Resume weight mismatch')
    for key,value in provenance.items():
        if record.get('provenance',{}).get(key)!=value:raise ValueError('Resume data mismatch: '+key)
    for key,value in (expected_config or {}).items():
        if record['config'].get(key)!=value:raise ValueError('Resume configuration mismatch: '+key)

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--output',type=Path,required=True)
    p.add_argument('--cache',type=Path,required=True)
    p.add_argument('--summary-output',type=Path,help='Optional live export directory')
    p.add_argument('--unimol2-checkpoint',type=Path,required=True)
    p.add_argument('--mmpolymer-checkpoint',type=Path,required=True)
    p.add_argument('--mmpolymer-source',type=Path,required=True)
    p.add_argument('--tokenizer-path',type=Path,required=True)
    p.add_argument('--models',nargs='+',choices=['UniMol2_84M','MMPolymer'],default=['UniMol2_84M','MMPolymer'])
    p.add_argument('--threads',type=int,default=3)
    p.add_argument('--batch-size',type=int,default=4)
    p.add_argument('--dry-run',action='store_true')
    a=p.parse_args()
    jobs=[j for j in build_jobs() if j['model'] in a.models]
    if a.dry_run:
        print(json.dumps([{**j,'manifest':str(j['manifest'])} for j in jobs],indent=2));return
    sys.path.insert(0,str(ROOT/'Models'))
    from shared_benchmark import load_split
    checkpoints={'UniMol2_84M':a.unimol2_checkpoint.resolve(),'MMPolymer':a.mmpolymer_checkpoint.resolve()}
    hashes={k:digest(v) for k,v in checkpoints.items() if k in a.models}
    import importlib.util
    sources={}
    if 'UniMol2_84M' in a.models:
        sources['UniMol2_84M']=dict(source_files=file_hashes(Path(importlib.util.find_spec('unimol_tools').origin).parent,{'.py'}))
    if 'MMPolymer' in a.models:
        sources['MMPolymer']=dict(source_files=file_hashes(a.mmpolymer_source,{'.py','.json','.txt'}),
                                 tokenizer_files=file_hashes(a.tokenizer_path,{'.json','.txt'}))
    a.output=a.output.resolve();a.cache=a.cache.resolve();a.output.mkdir(parents=True,exist_ok=True)
    lock=a.output/'.batch.lock'
    try:fd=os.open(lock,os.O_CREAT|os.O_EXCL|os.O_WRONLY)
    except FileExistsError:raise RuntimeError('Batch lock exists; verify old batch stopped before removing it')
    os.write(fd,str(os.getpid()).encode());os.close(fd)
    try:
        # Verify every existing prediction artifact before treating a run as done.
        from summarize_added_models import collect
        collect(a.output)
        for number,j in enumerate(jobs,1):
            out=a.output/j['key'];out.mkdir(parents=True,exist_ok=True)
            bundle=load_split(j['manifest'],j['fold'],j['train_size'])
            adapter='UniMol2' if j['model']=='UniMol2_84M' else 'MMPolymer'
            if (out/'metrics.json').exists():
                from importlib.metadata import version
                check_resume(json.loads((out/'metrics.json').read_text()),j,hashes[j['model']],
                    dict(canonical_sha256=bundle.canonical_sha256,indices_sha256=bundle.indices_sha256),
                    dict(batch_size=a.batch_size,effective_batch_size=32,learning_rate=1e-4,seed=42+j['fold'],
                         adapter_sha256=digest(ROOT/'Models'/adapter/'train_scaling.py'),
                         shared_sha256=digest(ROOT/'Models/shared_benchmark.py'),
                         **({'full_finetune':True} if adapter=='UniMol2' else {'full_finetuning':True}),
                         **sources[j['model']],
                         runtime_versions={p:version(p) for p in ('torch','numpy','rdkit','transformers')}))
                print('SKIP',number,j['key'],flush=True);continue
            cmd=[sys.executable,'-u',str(ROOT/'Models'/adapter/'train_scaling.py'),
                 '--manifest',str(j['manifest']),'--fold',str(j['fold']),'--train-size',str(j['train_size']),
                 '--checkpoint',str(checkpoints[j['model']]),'--output',str(out),
                 '--cache',str(a.cache/adapter),'--epochs','50','--threads',str(a.threads),
                 '--batch-size',str(a.batch_size)]
            if adapter=='MMPolymer':cmd+=['--source-root',str(a.mmpolymer_source.resolve()),'--tokenizer-path',str(a.tokenizer_path.resolve())]
            status=dict(job=j['key'],number=number,total=len(jobs),started=time.time(),command=cmd,status='running')
            (a.output/'progress.json').write_text(json.dumps(status,indent=2))
            print('START',number,'/',len(jobs),j['key'],flush=True)
            with (out/'training.log').open('a') as log:result=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT)
            status.update(returncode=result.returncode,finished=time.time(),status='complete' if result.returncode==0 else 'failed')
            (a.output/'progress.json').write_text(json.dumps(status,indent=2))
            if result.returncode:raise RuntimeError('Training failed; inspect '+str(out/'training.log'))
            subprocess.run([sys.executable,str(ROOT/'scripts/summarize_added_models.py'),'--input',str(a.output),'--output',str(a.summary_output.resolve() if a.summary_output else a.output/'summary')],check=True)
            print('DONE',j['key'],flush=True)
    finally:lock.unlink()

if __name__=='__main__':main()
