import sys
import unittest
from pathlib import Path
from rdkit import Chem

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'Models/UniMol2'))
from train_scaling import cap_endpoints, validate_epochs, checkpoint_backbone


class AdapterTests(unittest.TestCase):
    def test_two_distinct_endpoint_types(self):
        mol = Chem.MolFromSmiles('*CO*')
        result = Chem.MolFromSmiles(cap_endpoints('*CO*'))
        self.assertEqual(result.GetNumAtoms(), mol.GetNumAtoms())
        self.assertEqual(sum(a.GetAtomicNum()==0 for a in result.GetAtoms()),0)
        self.assertEqual(sorted(a.GetSymbol() for a in result.GetAtoms()),['C','C','O','O'])

    def test_invalid_endpoint_count_fails(self):
        for smiles in ['CCO','*CC','*C(*)*']:
            with self.assertRaises(ValueError): cap_endpoints(smiles)

    def test_budget(self):
        self.assertEqual(validate_epochs(50),50)
        for n in [0,51,-1]:
            with self.assertRaises(ValueError): validate_epochs(n)

    def test_checkpoint_does_not_silently_skip_backbone(self):
        with self.assertRaises(ValueError):
            checkpoint_backbone({'encoder.weight': 1}, {'other.weight': 2})
        self.assertEqual(checkpoint_backbone({'encoder.weight': 1,'classification_head.x':3},
                                             {'encoder.weight':2,'classification_head.y':4}),{'encoder.weight':2})

if __name__=='__main__':unittest.main()
