import hashlib
import json
from pathlib import Path
import tempfile
import unittest
import numpy as np
import pandas as pd
from sklearn.metrics import r2_score
from Models.shared_benchmark import load_split, write_run


class SharedBenchmarkTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)
        self.source = self.root / 'Datasets/PSMILES/toy.csv'
        self.source.parent.mkdir(parents=True)
        pd.DataFrame({'smiles': ['C' * (i + 1) for i in range(10)], 'T': np.arange(10.)}).to_csv(self.source, index=False)
        self.path = self.root / 'Datasets/scaling_indices/toy/seed_42/manifest.json'
        self.path.parent.mkdir(parents=True)
        self.manifest = dict(canonical_source='PSMILES/toy.csv', canonical_sha256=hashlib.sha256(self.source.read_bytes()).hexdigest(), target_column='T', n_rows=10, train_sizes=[2, 4], num_folds=1, folds=[dict(fold=0, indices_file='fold_00.npz', n_train_pool=6, n_val=2, n_test=2)])
        self.save_manifest()
        self.save_indices()

    def save_manifest(self):
        self.path.write_text(json.dumps(self.manifest))

    def save_indices(self, train=None, val=None, test=None):
        np.savez(self.path.parent / 'fold_00.npz', train_pool=[5, 0, 4, 2, 1, 3] if train is None else train, val=[6, 7] if val is None else val, test=[9, 8] if test is None else test)

    def test_preserves_published_order_and_columns(self):
        b = load_split(self.path, 0, 2)
        self.assertEqual(list(b.train.columns), ['row_index', 'smiles', 'target'])
        self.assertEqual(b.train.row_index.tolist(), [5, 0])
        self.assertEqual(b.test.row_index.tolist(), [9, 8])
        self.assertEqual(b.target_column, 'T')
        self.assertEqual(b.canonical_sha256, self.manifest['canonical_sha256'])

    def test_real_published_indices_identity(self):
        path = Path(__file__).resolve().parents[1] / 'Datasets/scaling_indices/MD_5000/Cp/homopolymer_Cp/seed_42/manifest.json'
        b = load_split(path, 0, 300)
        with np.load(path.parent / 'fold_00.npz') as indices:
            for split, key in [('train', 'train_pool'), ('val', 'val'), ('test', 'test')]:
                expected = indices[key][:300] if split == 'train' else indices[key]
                np.testing.assert_array_equal(getattr(b, split).row_index.to_numpy(), expected)

    def test_config_fingerprints_deterministic_and_sensitive(self):
        b = load_split(self.path,0,2)
        preds = {s: getattr(b,s).target.to_numpy() for s in ('train','val','test')}
        first = write_run(self.root/'one','toy',b,preds,{'seed':42,'epochs':50})
        second = write_run(self.root/'two','toy',b,preds,{'epochs':50,'seed':42})
        third = write_run(self.root/'three','toy',b,preds,{'epochs':49,'seed':42})
        self.assertEqual(first['run_fingerprint'],second['run_fingerprint'])
        self.assertNotEqual(first['run_fingerprint'],third['run_fingerprint'])

    def test_rejects_source_tampering(self):
        self.source.write_text(self.source.read_text() + '\n')
        with self.assertRaises(ValueError): load_split(self.path, 0, 2)

    def test_rejects_invalid_size_and_fold(self):
        for fold, size in [(0, 0), (0, -1), (0, 3), (2, 2), (0, True), (False, 2)]:
            with self.subTest(fold=fold, size=size), self.assertRaises(ValueError): load_split(self.path, fold, size)

    def test_validates_full_pool_leakage_counts_and_indices(self):
        for train, val, test in [([5,0,4,2,1,6], None, None), ([5,0,4,2,1,1],None,None), (None,[6],None), (None,None,[9,10]), (None,None,[9.,8.])]:
            self.save_indices(train, val, test)
            with self.assertRaises(ValueError): load_split(self.path, 0, 2)

    def test_rejects_nonfinite_source_labels(self):
        df = pd.read_csv(self.source); df.loc[3,'T'] = float('inf'); df.to_csv(self.source,index=False)
        self.manifest['canonical_sha256'] = hashlib.sha256(self.source.read_bytes()).hexdigest(); self.save_manifest()
        with self.assertRaises(ValueError): load_split(self.path,0,2)

    def test_write_metrics_predictions_fingerprint_and_no_overwrite(self):
        b = load_split(self.path,0,2)
        preds = {s: getattr(b,s).target.to_numpy() + .5 for s in ('train','val','test')}
        out = self.root / 'run'
        result = write_run(out,'toy',b,preds,{'seed':42})
        self.assertEqual(result, json.loads((out/'metrics.json').read_text()))
        self.assertEqual(result['status'], 'complete')
        self.assertEqual(result['target_columns'], ['T'])
        self.assertEqual(len(result['config_fingerprint']),64)
        for s in preds:
            m = result['metrics'][s]
            self.assertAlmostEqual(m['rmse'],.5)
            self.assertAlmostEqual(m['r2'], r2_score(getattr(b,s).target,preds[s]))
            self.assertEqual(m['n_samples'],2)
            self.assertEqual(pd.read_csv(out/f'preds_{s}.csv').row_index.tolist(),getattr(b,s).row_index.tolist())
        with self.assertRaises(FileExistsError): write_run(out,'toy',b,preds,{'seed':43})

    def test_invalid_predictions_never_complete(self):
        b=load_split(self.path,0,2)
        for bad in [None,[1], [1,float('nan')], [[1],[2]]]:
            preds={s: getattr(b,s).target.to_numpy() for s in ('train','val','test')}
            if bad is None: del preds['test']
            else: preds['test']=bad
            out=self.root/'invalid'
            with self.assertRaises(ValueError): write_run(out,'toy',b,preds,{})
            self.assertFalse((out/'metrics.json').exists())

    def test_constant_label_r2_rejected(self):
        b=load_split(self.path,0,2); b.val['target']=1.
        preds={s: getattr(b,s).target.to_numpy() for s in ('train','val','test')}
        with self.assertRaises(ValueError): write_run(self.root/'constant','toy',b,preds,{})

if __name__ == '__main__': unittest.main()
