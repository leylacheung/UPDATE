import importlib.util
from pathlib import Path
import numpy as np
import pytest

PATH = Path(__file__).resolve().parents[1] / 'Models/MMPolymer/train_scaling.py'
def adapter():
    spec = importlib.util.spec_from_file_location('mm_adapter', PATH)
    m = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m)
    return m

def test_budget_and_missing_weights(tmp_path):
    m = adapter()
    for epochs in (0, 51):
        with pytest.raises(ValueError, match='epochs'):
            m.validate_options(epochs, 4, 32)
    m.validate_options(50, 4, 32)
    with pytest.raises(FileNotFoundError, match='pretrained'):
        m.require_checkpoint(tmp_path / 'absent.pt')

def test_geometry_keeps_endpoints_and_rejects_misalignment():
    m = adapter()
    record = dict(atoms=['*', 'C', '*', 'H'], coordinates=[np.zeros((4,3))]*11)
    atoms, coords = m.geometry(record, 0, 42)
    assert atoms == ['*', 'C', '*']
    assert coords.shape == (3,3)
    record['coordinates'][0] = np.zeros((3,3))
    with pytest.raises(ValueError, match='align'):
        m.geometry(record, 0, 42)

def test_train_scaling_and_conformer_order():
    m = adapter()
    assert m.fit_scaler([1, 3]) == (2., 1.)
    values = np.arange(22.)
    np.testing.assert_array_equal(m.average_conformers(values, 2), [5.,16.])
    with pytest.raises(ValueError):
        m.average_conformers(values[:-1], 2)

def test_checkpoint_rejects_missing_encoder(tmp_path):
    torch = pytest.importorskip('torch')
    m = adapter()
    model = torch.nn.Linear(2, 1)
    path = tmp_path/'weights.pt'
    torch.save({'model': {}}, path)
    with pytest.raises(ValueError, match='missing'):
        m.load_pretrained(model, path)

def test_official_geometry_generates_eleven_and_preserves_rows(tmp_path):
    source = Path(__file__).resolve().parents[2]/'new_model_sources/MMPolymer'
    if not source.exists():
        pytest.skip('external official source unavailable')
    spec = importlib.util.spec_from_file_location('mm_official_preprocess_test', source/'dataset/finetune_data_process.py')
    upstream = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(upstream)
    record = upstream.inner_smi2coords(('*CC*',0.))
    assert len(record['coordinates']) == 11
    assert record['origin_smi'] == '*CC*'
    assert record['atoms'].count('*') == 2
    for i in range(11):
        atoms, xyz = adapter().geometry(record,i,42)
        assert len(atoms) == len(xyz)
    with pytest.raises(Exception):
        upstream.inner_smi2coords(('CCC',0.))

def test_endpoint_mapping_follows_canonical_atom_reordering():
    from rdkit import Chem
    m = adapter()
    original = '*C(=O)NCC*'
    substituted = Chem.MolFromSmiles('CCCNC(C)=O')
    record = {'origin_smi':original, 'mol':Chem.AddHs(substituted), 'atoms':['*','C','C','N','C','C','*']}
    corrected = m.restore_canonical_endpoints(record)
    assert [i for i,a in enumerate(corrected['atoms']) if a == '*'] == [0,5]
    assert corrected['atoms'][6] == 'O'

def test_checkpoint_accepts_only_exact_nonpersistent_position_buffer(tmp_path):
    import torch
    m=adapter()
    model=torch.nn.Module()
    model.PretrainedModel=torch.nn.Module()
    model.PretrainedModel.embeddings=torch.nn.Module()
    model.PretrainedModel.embeddings.register_buffer('position_ids',torch.arange(4).reshape(1,4),persistent=False)
    model.weight=torch.nn.Parameter(torch.ones(1))
    path=tmp_path/'positions.pt'
    torch.save({'model':{'weight':torch.zeros(1),'PretrainedModel.embeddings.position_ids':torch.arange(4).reshape(1,4)}},path)
    m.load_pretrained(model,path)
    torch.save({'model':{'weight':torch.zeros(1),'PretrainedModel.embeddings.position_ids':torch.zeros((1,4),dtype=torch.long)}},path)
    with pytest.raises(ValueError,match='position'):
        m.load_pretrained(model,path)

def test_endpoint_mapping_uses_exact_generated_smiles_before_recanonicalization():
    from rdkit import Chem
    m=adapter()
    original='C=CC(C)(CC(=O)NCCCO[*])OC(=O)[*]'
    generated='COCCCNC(=O)CC(C)(C=C)OC(O)=O'
    record={'origin_smi':original,'smi':generated,'mol':Chem.AddHs(Chem.MolFromSmiles(generated))}
    corrected=m.restore_canonical_endpoints(record)
    assert [i for i,a in enumerate(corrected['atoms']) if a=='*'] == [0,15]
