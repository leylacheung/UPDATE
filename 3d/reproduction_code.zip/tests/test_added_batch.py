import importlib.util
from pathlib import Path
import unittest
from unittest.mock import patch
import tempfile
import json
import sys
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "scripts"))
import summarize_added_models as summary

ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('batch', ROOT/'scripts/run_added_models.py')
batch=importlib.util.module_from_spec(spec)
spec.loader.exec_module(batch)

class MatrixTests(unittest.TestCase):
    def test_exact_approved_matrix(self):
        jobs=batch.build_jobs(ROOT)
        self.assertEqual(len(jobs),290)
        self.assertEqual(len({j['key'] for j in jobs}),290)
        self.assertEqual({j['model'] for j in jobs},{'UniMol2_84M','MMPolymer'})
        self.assertEqual({j['fold'] for j in jobs},set(range(5)))
        self.assertTrue(all(j['manifest'].is_file() for j in jobs))
    def test_smoke_cannot_resume_as_benchmark(self):
        record={'status':'complete','model':'UniMol2_84M','fold':0,'train_size':300,
                'config':{'epochs':1,'checkpoint_sha256':'a'}}
        job={'model':'UniMol2_84M','fold':0,'train_size':300}
        with self.assertRaises(ValueError):
            batch.check_resume(record,job,'a',{})

    def test_resume_requires_expected_static_configuration(self):
        job={'model':'UniMol2_84M','fold':0,'train_size':300}
        expected={'batch_size':4,'learning_rate':1e-4,'full_finetune':True,
                  'adapter_sha256':'adapter','shared_sha256':'shared',
                  'runtime_versions':{'torch':'verified-version'}}
        record={**job,'status':'complete','config':{'epochs':50,'checkpoint_sha256':'weight',**expected}}
        batch.check_resume(record,job,'weight',{},expected)
        for key in expected:
            changed={**record,'config':{**record['config'],key:None}}
            with self.subTest(key=key),self.assertRaisesRegex(ValueError,'configuration mismatch'):
                batch.check_resume(changed,job,'weight',{},expected)

    def test_collector_rejects_misplaced_model_fold_or_size(self):
        job={'key':'run','model':'MMPolymer','fold':0,'train_size':300,
             'experiment':'toy/T/homopolymer_T'}
        with tempfile.TemporaryDirectory() as directory:
            root=Path(directory);(root/'run').mkdir()
            for field,wrong in [('model','UniMol2_84M'),('fold',1),('train_size',600)]:
                record={**job,field:wrong,'status':'complete','config':{'epochs':50}}
                (root/'run/metrics.json').write_text(json.dumps(record))
                with self.subTest(field=field),patch.object(summary,'build_jobs',return_value=[job]):
                    with self.assertRaisesRegex(ValueError,'Run identity mismatch'):
                        summary.collect(root)

    def test_aggregation_population_sd_and_partial_coverage(self):
        for values,expected_std in [([1.],0.),([1.,3.],1.)]:
            rows=[dict(experiment='toy/T/homopolymer_T',dataset='toy',quantity='T',
                       polymer_type='homopolymer',model='UniMol2_84M',train_size=300,
                       fold=i,split='test',rmse=v,r2=v,mse=v,mae=v)
                  for i,v in enumerate(values)]
            coverage=pd.DataFrame({'complete':[True]*len(values)+[False]*(5-len(values))})
            with self.subTest(folds=len(values)),tempfile.TemporaryDirectory() as directory:
                root=Path(directory)
                with patch.object(summary,'collect',return_value=(pd.DataFrame(rows),coverage)),patch.object(sys,'argv',['summary','--input',directory,'--output',directory]):
                    summary.main()
                aggregate=pd.read_csv(root/'scaling_results_aggregate.csv').iloc[0]
                for metric in ['rmse','r2','mse','mae']:
                    self.assertAlmostEqual(aggregate[metric+'_std'],expected_std)
                self.assertEqual(aggregate.completed_folds,len(values))
                self.assertFalse(aggregate.complete)
                self.assertIn('ddof=0',json.loads((root/'status.json').read_text())['r2_aggregation'])

if __name__=='__main__':unittest.main()
