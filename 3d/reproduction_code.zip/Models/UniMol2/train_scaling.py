"""Uni-Mol2-84M full fine-tuning on published PolyBench26 indices.

Uses the upstream model and graph featurizer, not MolTrain's automatic split.
The polymer endpoint adaptation and CPU training policy are explicitly recorded.
"""
from pathlib import Path
import argparse
import hashlib
import json
import pickle
import random
import sys
import time

UPSTREAM_REVISION = '670afbd3144b58caef1d76cc618ddfeaecab8424'
WEIGHT_REVISION = 'bf37d253c0f5ac61f468137eb00059978a104ff0'


def cap_endpoints(smiles):
    """Replace each '*' by the element adjacent to the opposite endpoint.

    This follows MMPolymer's coordinate-generation atom substitution. Uni-Mol2
    consumes the substituted molecule because its atomic vocabulary has no
    polymer endpoint token. Original PSMILES and row_index are never replaced.
    """
    from rdkit import Chem
    mol = Chem.MolFromSmiles(smiles)
    if mol is None:
        raise ValueError(f'Invalid PSMILES: {smiles}')
    ends = [a for a in mol.GetAtoms() if a.GetAtomicNum() == 0]
    if len(ends) != 2 or any(a.GetDegree() != 1 for a in ends):
        raise ValueError(f'Expected two degree-one endpoints: {smiles}')
    numbers = [a.GetNeighbors()[0].GetAtomicNum() for a in ends]
    if min(numbers) <= 0:
        raise ValueError('Endpoint neighbors must be real atoms')
    for atom, number in zip(ends, reversed(numbers)):
        atom.SetAtomicNum(number)
    Chem.SanitizeMol(mol)
    return Chem.MolToSmiles(mol)


def validate_epochs(value):
    if not 1 <= int(value) <= 50:
        raise ValueError('Approved epoch budget is 1..50')
    return int(value)


def checkpoint_backbone(model_state, state):
    required = {k for k in model_state if not k.startswith('classification_head.')}
    missing = required - state.keys()
    if missing:
        raise ValueError(f'Pretrained backbone missing {len(missing)} keys: {sorted(missing)[:5]}')
    return {k:state[k] for k in required}


def sha256(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        for chunk in iter(lambda:f.read(1024*1024),b''):h.update(chunk)
    return h.hexdigest()


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--manifest',type=Path,required=True)
    p.add_argument('--fold',type=int,required=True)
    p.add_argument('--train-size',type=int,required=True)
    p.add_argument('--checkpoint',type=Path,required=True)
    p.add_argument('--output',type=Path,required=True)
    p.add_argument('--cache',type=Path,required=True)
    p.add_argument('--epochs',type=int,default=50)
    p.add_argument('--batch-size',type=int,default=4)
    p.add_argument('--effective-batch-size',type=int,default=32)
    p.add_argument('--learning-rate',type=float,default=1e-4)
    p.add_argument('--seed',type=int,default=42)
    p.add_argument('--threads',type=int,default=4)
    p.add_argument('--device',choices=['cpu','cuda'],default='cpu')
    args=p.parse_args();validate_epochs(args.epochs)
    if not args.checkpoint.is_file():raise FileNotFoundError(args.checkpoint)
    if args.batch_size<1 or args.effective_batch_size<args.batch_size or args.effective_batch_size%args.batch_size:
        raise ValueError('Effective batch size must be a positive multiple of batch size')
    if (args.output/'metrics.json').exists():raise FileExistsError('Completed run exists; do not overwrite')

    import numpy as np
    import torch
    from torch.utils.data import DataLoader
    import rdkit
    from unimol_tools.models.unimolv2 import UniMolV2Model
    from unimol_tools.data.conformer import UniMolV2Feature
    sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
    from shared_benchmark import load_split,write_run
    torch.set_num_threads(args.threads)
    seed=args.seed+args.fold
    random.seed(seed);np.random.seed(seed);torch.manual_seed(seed)
    bundle=load_split(args.manifest,args.fold,args.train_size)
    args.output.mkdir(parents=True,exist_ok=True);args.cache.mkdir(parents=True,exist_ok=True)
    from importlib.metadata import version
    import unimol_tools
    source_root=Path(unimol_tools.__file__).resolve().parent
    config=dict(model='UniMol2_84M',upstream_revision=UPSTREAM_REVISION,weight_revision=WEIGHT_REVISION,
        source_files={str(p.relative_to(source_root)):sha256(p) for p in sorted(source_root.rglob('*.py'))},
        adapter_sha256=sha256(__file__),shared_sha256=sha256(Path(__file__).resolve().parents[1]/'shared_benchmark.py'),
        runtime_versions={p:version(p) for p in ('torch','numpy','rdkit','transformers')},
        checkpoint_sha256=sha256(args.checkpoint),epochs=args.epochs,batch_size=args.batch_size,
        effective_batch_size=args.effective_batch_size,learning_rate=args.learning_rate,seed=seed,
        device=args.device,torch_version=torch.__version__,rdkit_version=rdkit.__version__,
        endpoint_policy='opposite_neighbor_element_substitution_v1',conformer_seed=42,
        max_atoms=256,remove_hs=True,loss='train_standardized_MSE',optimizer='Adam',
        betas=[.9,.99],eps=1e-6,weight_decay=0,warmup_ratio=.06,scheduler='linear_decay',
        selection='minimum validation RMSE',precision='float32',full_finetune=True)
    (args.output/'run_config.json').write_text(json.dumps(config,indent=2))
    start=time.time()
    generator=UniMolV2Feature(seed=42,max_atoms=256,remove_hs=True,multi_process=False)
    features={};audit=[]
    for frame in [bundle.train,bundle.val,bundle.test]:
        for row in frame.itertuples(index=False):
            if row.smiles in features:continue
            cap=cap_endpoints(row.smiles)
            from rdkit import Chem
            expected_atoms=Chem.RemoveHs(Chem.MolFromSmiles(cap)).GetNumAtoms()
            if expected_atoms>256:raise ValueError('Input exceeds atom limit; refusing silent cropping')
            identity=dict(smiles=row.smiles,capped_smiles=cap,seed=42,max_atoms=256,
                          rdkit=rdkit.__version__,upstream=UPSTREAM_REVISION,policy=config['endpoint_policy'])
            key=hashlib.sha256(json.dumps(identity,sort_keys=True).encode()).hexdigest()
            cache=args.cache/f'{key}.pkl'
            if cache.exists():
                with cache.open('rb') as f:record=pickle.load(f)
                if record['identity']!=identity:raise ValueError('Feature cache provenance mismatch')
                feat=record['features']
            else:
                feat,_=generator.single_process(cap)
                if len(feat['src_tokens'])!=expected_atoms:raise ValueError('Unexpected atom cropping')
                if not np.isfinite(feat['src_coord']).all() or not np.any(feat['src_coord']):
                    raise ValueError(f'Invalid coordinates for canonical row {row.row_index}')
                with cache.with_suffix('.tmp').open('wb') as f:pickle.dump({'identity':identity,'features':feat},f)
                cache.with_suffix('.tmp').replace(cache)
            if not np.isfinite(feat['src_coord']).all() or not np.any(feat['src_coord']):
                raise ValueError('Invalid cached coordinates')
            if len(feat['src_tokens'])!=expected_atoms:raise ValueError('Cached atom count mismatch')
            features[row.smiles]=feat
            audit.append(dict(row_index=int(row.row_index),**identity,
                              planar=bool(np.all(np.asarray(feat['src_coord'])[:,2]==0))))
            if len(features)%100==0:print('FEATURES',len(features),flush=True)
    (args.output/'feature_audit.json').write_text(json.dumps(audit,indent=2))
    model=UniMolV2Model(output_dim=1,model_size='84m',load_pretrained=False,remove_hs=True)
    state=torch.load(args.checkpoint,map_location='cpu',weights_only=False)
    state=state.get('model',state.get('model_state_dict',state))
    model.load_state_dict(checkpoint_backbone(model.state_dict(),state),strict=False)
    del state
    print('PRETRAINED_BACKBONE_LOADED',flush=True)
    for param in model.parameters():param.requires_grad_(True)
    model.to(args.device)
    mean=float(bundle.train.target.mean());std=float(bundle.train.target.std(ddof=0))
    if not np.isfinite(std) or std<=0:raise ValueError('Training labels have zero/invalid variance')
    config.update(target_mean=mean,target_std=std)
    def loader(frame,shuffle=False):
        samples=[(features[r.smiles],[(float(r.target)-mean)/std]) for r in frame.itertuples(index=False)]
        return DataLoader(samples,batch_size=args.batch_size,shuffle=shuffle,num_workers=0,
                          collate_fn=model.batch_collate_fn,generator=torch.Generator().manual_seed(seed))
    train_loader=loader(bundle.train,True)
    loaders={k:loader(getattr(bundle,k)) for k in ['train','val','test']}
    def predict(data):
        model.eval();result=[]
        with torch.no_grad():
            for batch,_ in data:
                batch={k:v.to(args.device) for k,v in batch.items()}
                result.extend(model(**batch).reshape(-1).cpu().numpy().astype(float)*std+mean)
        result=np.asarray(result)
        if not np.isfinite(result).all():raise ValueError('Non-finite model predictions')
        return result
    optimizer=torch.optim.Adam(model.parameters(),lr=args.learning_rate,betas=(.9,.99),eps=1e-6)
    accumulation=args.effective_batch_size//args.batch_size
    steps_per_epoch=(len(train_loader)+accumulation-1)//accumulation
    total_steps=args.epochs*steps_per_epoch;warmup=max(1,int(total_steps*.06))
    def rate(step):return min((step+1)/warmup,max(0,(total_steps-step)/max(1,total_steps-warmup)))
    scheduler=torch.optim.lr_scheduler.LambdaLR(optimizer,rate)
    best=float('inf');history=[]
    for epoch in range(args.epochs):
        model.train();optimizer.zero_grad();total_loss=0;count=0
        for i,(batch,y) in enumerate(train_loader):
            batch={k:v.to(args.device) for k,v in batch.items()};y=y.float().to(args.device)
            # Normalize by the actual sample count in this accumulation group.
            group_start=(i//accumulation)*args.effective_batch_size
            denominator=min(args.effective_batch_size,len(bundle.train)-group_start)
            loss=torch.nn.functional.mse_loss(model(**batch),y,reduction='sum')/denominator
            if not torch.isfinite(loss):raise ValueError('Non-finite training loss')
            loss.backward();total_loss+=float(loss.detach());count+=1
            if (i+1)%accumulation==0 or i+1==len(train_loader):
                torch.nn.utils.clip_grad_norm_(model.parameters(),1.0)
                optimizer.step();scheduler.step();optimizer.zero_grad()
                print('TRAIN_STEP',epoch+1,i+1,'/',len(train_loader),flush=True)
        val=predict(loaders['val']);rmse=float(np.sqrt(np.mean((val-bundle.val.target.to_numpy())**2)))
        history.append(dict(epoch=epoch+1,val_rmse=rmse,elapsed_seconds=time.time()-start))
        if rmse<best:
            best=rmse;best_epoch=epoch+1
            torch.save({'model':model.state_dict(),'config':config,'best_epoch':best_epoch},args.output/'best.pt')
        (args.output/'history.json').write_text(json.dumps(history,indent=2))
        print('EPOCH',epoch+1,'VAL_RMSE',rmse,'SECONDS',round(time.time()-start,1),flush=True)
    model.load_state_dict(torch.load(args.output/'best.pt',map_location=args.device,weights_only=False)['model'])
    predictions={k:predict(v) for k,v in loaders.items()}
    config.update(best_epoch=best_epoch,elapsed_seconds=time.time()-start,planar_features=sum(x['planar'] for x in audit))
    write_run(args.output,'UniMol2_84M',bundle,predictions,config)
    print('COMPLETE',args.output,flush=True)


if __name__=='__main__':main()
