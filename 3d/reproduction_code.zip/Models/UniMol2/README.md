# Uni-Mol2-84M benchmark adapter

Uses `deepmodeling/unimol_tools` revision
`670afbd3144b58caef1d76cc618ddfeaecab8424`, official `dptech/Uni-Mol2`
84M checkpoint at revision `bf37d253c0f5ac61f468137eb00059978a104ff0`.
Every backbone tensor must exist; shape mismatch is fatal. Only the scalar
regression head is initialized anew. All parameters are eligible for training.

The published manifest determines canonical row order, training prefix,
validation and test indices. No library automatic split is used. Label mean
and population standard deviation are fitted only on the training prefix.
50 epochs, effective batch32, microbatch4, Adam lr1e-4, betas(.9,.99), eps1e-6,
6% warmup then linear decay, gradient clipping1, float32 CPU. Seed42+fold.
The lowest validation RMSE selects the checkpoint; test is evaluated afterward.

Uni-Mol2 is a small-molecule model. Each polymer endpoint dummy is substituted
with the element adjacent to the opposite endpoint before official conformer
generation. This is an explicit input adaptation, not a periodic polymer
representation. Original PSMILES and canonical row identities remain intact.
One conformer per molecule, seed42, no hydrogens, max256 heavy atoms. All current
benchmark molecules fit this limit. Invalid inputs are fatal, never dropped.
Feature audit records capped SMILES and planar fallback; cache keys include
RDKit version and preprocessing policy. MMPolymer uses its separate original
11-conformer convention, documented in its adapter README.

`train_scaling.py --help` lists explicit paths and arguments. For diagnostics,
`--epochs 1` produces a smoke run; it must not enter the 50-epoch aggregate.
`scripts/run_added_models.py` drives the approved 290-run matrix sequentially.
Completed runs can resume only with matching data, weights and adapter/runtime
configuration. Interrupted individual runs restart from their first epoch.

Each split saves `preds_<split>.csv` with row_index, y_true, y_pred. Metrics use
original target units. R2=1-MSE/Var(y,ddof=0) is crosschecked against sklearn
on these same predictions. Across folds, mean and population SD (ddof=0) are
reported separately, with completed_fold counts; R2 is never inferred from
aggregate RMSE. Equal epoch caps do not imply equal compute budgets.
