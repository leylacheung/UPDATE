# MMPolymer published-split adapter

Runs full-parameter fine-tuning of **both** official sequence RoBERTa and
3D transformer pathways at upstream revision
`97bce5448a6ce0b993bd93e64a76f9974951ef3d`. External GPL-3.0 code and its
LICENSE.txt stay under `work/new_model_sources/MMPolymer`. No GPL source is
vendored here. Uni-Core is required (tested revision
`ace6fae1c8479a9751f2bb1e1d6e4047427bc134`).

```sh
python Models/MMPolymer/train_scaling.py \
  --manifest Datasets/scaling_indices/CONDITION/manifest.json \
  --fold 0 --train-size 100 --checkpoint /absolute/path/pretrained.pt \
  --source-root /absolute/path/MMPolymer --tokenizer /absolute/path/roberta-base \
  --cache /absolute/path/mm-cache --output /absolute/path/run \
  --epochs 50 --batch-size 4 --effective-batch-size 32 --device cpu --threads 4
```

Use the actual manifest location and supported size. The official checkpoint
is linked by upstream from Google Drive ID `1GFE9JmFSveU-cyiYzoB8PPJm-f-7PPWM`.
Missing weights fail before preprocessing. Backbone keys must all load; only
pretraining-only heads can be ignored and the regression head may initialize
fresh. Shape mismatches fail. The old Transformers persistent position_ids buffer
is accepted only when exactly equal to the current nonpersistent buffer. The local tokenizer directory needs the original
RoBERTa `vocab.json` and `merges.txt`; network access is never implicit. The
custom upstream SMILES tokenizer is retained. A compatibility subclass seeds
its vocabulary before the Transformers base initializer. Model construction
uses upstream local config and injects this same tokenizer.

Preprocessing calls official `inner_smi2coords`: exactly two singly connected
`*` atoms are required, each temporarily takes the atom type neighboring the
opposite endpoint, followed by ten 3D conformers and one 2D conformer. Official
2D fallbacks remain enabled. Upstream endpoint restoration incorrectly uses original atom indices after
canonicalizing SMILES. This adapter explicitly corrects endpoint indices using
RDKit `_smilesAtomOutputOrder`, preserving the original canonical coordinates.
For `*C(=O)NCC*`, original indices [0,6] map to canonical [5,0]; upstream
incorrectly marks oxygen at index 6. The regression test checks this case. All H atoms are removed, coordinates centered,
and a deterministic max-256 atom crop used. Sequence encoding uses original
PSMILES with upstream length-411 truncation. No rows are removed; exceptions
name the original row. Cache keys include row index, original SMILES, canonical
SHA, upstream Python source hashes and tokenizer vocabulary hash. Every split
retains manifest order. Training samples one of eleven conformers per row each
epoch; evaluation averages eleven predictions per row.

Adaptations from official train.sh: float32 CPU instead of fp16/distributed;
maximum 50 epochs instead of 600; seed 42+fold instead of 0; train-only target
standardization and MSE; constant Adam LR (default 1e-4) instead of polynomial
schedule/warmup; checkpoint selected by validation RMSE instead of R2. Adam
betas (0.9,0.99), epsilon 1e-6, norm clipping 1, effective batch size 32 remain.
The final short accumulation group divides by its actual number of molecules.
All parameters remain trainable; classification_head_name activates the
upstream differentiable two-path regression forward. Test labels are used only
by the shared final evaluator after checkpoint selection.

Outputs: best.pt, per-epoch history.json, original-row-index predictions for
train/val/test, and shared metrics.json with RMSE, direct R2, sklearn R2 and
provenance. A completed directory is never overwritten. Failure leaves no
completion metadata. Training must be validated with real official weights
before interpreting any benchmark outcome.
