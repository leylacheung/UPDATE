"""Row-preserving full fine-tuning of the external official MMPolymer model."""
import argparse
from contextlib import contextmanager
import hashlib
import importlib.util
import json
import math
import os
from pathlib import Path
import pickle
import random
import sys
import time
from types import SimpleNamespace

import numpy as np

UPSTREAM_REVISION = '97bce5448a6ce0b993bd93e64a76f9974951ef3d'

def sha(path):
    h = hashlib.sha256()
    with open(path, 'rb') as f:
        for block in iter(lambda: f.read(1024*1024), b''):
            h.update(block)
    return h.hexdigest()

def require_checkpoint(path):
    path = Path(path)
    if not path.is_file():
        raise FileNotFoundError('Official pretrained MMPolymer checkpoint required: ' + str(path))
    return path

def validate_options(epochs, batch_size, effective_batch_size):
    if not 1 <= epochs <= 50:
        raise ValueError('epochs must be between 1 and 50')
    if batch_size < 1 or effective_batch_size < batch_size or effective_batch_size % batch_size:
        raise ValueError('effective batch size must be a positive multiple of batch size')

def fit_scaler(target):
    values = np.asarray(target, dtype=float)
    return float(values.mean()), float(values.std()) or 1.

def average_conformers(values, rows):
    values = np.asarray(values)
    if values.shape != (rows*11,):
        raise ValueError('Expected exactly eleven ordered conformers per row')
    return values.reshape(rows, 11).mean(axis=1)

def restore_canonical_endpoints(record):
    """Correct upstream endpoint indices after canonical SMILES reordering."""
    import ast
    from rdkit import Chem
    mol = Chem.MolFromSmiles(record['origin_smi'])
    stars = [a.GetIdx() for a in mol.GetAtoms() if a.GetAtomicNum() == 0]
    if len(stars) != 2 or any(len(mol.GetAtomWithIdx(i).GetNeighbors()) != 1 for i in stars):
        raise ValueError('Expected exactly two singly connected endpoints')
    neighbors = [mol.GetAtomWithIdx(i).GetNeighbors()[0].GetIdx() for i in stars]
    atomic_numbers = [mol.GetAtomWithIdx(i).GetAtomicNum() for i in neighbors]
    for i, z in zip(stars, atomic_numbers[::-1]):
        mol.GetAtomWithIdx(i).SetAtomicNum(z)
    canonical = Chem.MolToSmiles(mol)
    order = ast.literal_eval(mol.GetProp('_smilesAtomOutputOrder'))
    # Coordinates were generated from this exact canonical substituted SMILES.
    if canonical != record.get('smi', Chem.MolToSmiles(Chem.RemoveHs(record['mol']))):
        raise ValueError('Canonical molecule mapping mismatch')
    atoms = [a.GetSymbol() for a in record['mol'].GetAtoms()]
    for original_index in stars:
        atoms[order.index(original_index)] = '*'
    record['atoms'] = atoms
    record['star_pair'] = [order.index(stars[0]),order.index(neighbors[0]),
                           order.index(stars[1]),order.index(neighbors[1])]
    return record

def geometry(record, conformer, seed):
    atoms = np.asarray(record['atoms'])
    xyz = np.asarray(record['coordinates'][conformer], dtype=np.float32)
    if xyz.shape != (len(atoms), 3) or not np.isfinite(xyz).all():
        raise ValueError('Atom/coordinate alignment or finite coordinate failure')
    mask = atoms != 'H'
    atoms, xyz = atoms[mask], xyz[mask]
    if len(atoms) > 256:
        select = np.random.RandomState(seed).choice(len(atoms), 256, replace=False)
        atoms, xyz = atoms[select], xyz[select]
    if len(atoms) == 0:
        raise ValueError('Empty geometry')
    return atoms.tolist(), xyz - xyz.mean(axis=0)

def load_pretrained(model, path):
    import torch
    checkpoint = torch.load(require_checkpoint(path), map_location='cpu', weights_only=False)
    state = checkpoint.get('model', checkpoint)
    expected = model.state_dict()
    position_key = 'PretrainedModel.embeddings.position_ids'
    if position_key in state and position_key not in expected:
        buffer = dict(model.named_buffers()).get(position_key)
        if buffer is None or not torch.equal(state[position_key], buffer):
            raise ValueError('Pretrained position_ids buffer mismatch')
        state = {k:v for k,v in state.items() if k != position_key}
    missing = [key for key in expected if key not in state and not key.startswith('classification_head.')]
    unexpected = [key for key in state if key not in expected and not key.startswith(('lm_head.', 'pair2coord_proj.', 'dist_head.'))]
    if missing or unexpected:
        raise ValueError(f'Official checkpoint mismatch: missing={missing}, unexpected={unexpected}')
    # Pretraining-only heads may be absent from the downstream architecture.
    model.load_state_dict({k:v for k,v in state.items() if k in expected}, strict=False)
    for parameter in model.parameters():
        parameter.requires_grad_(True)

@contextmanager
def source_cwd(source):
    previous = Path.cwd()
    os.chdir(source)
    try:
        yield
    finally:
        os.chdir(previous)

def load_external(source, tokenizer_path):
    """Import external GPL code without copying it into this checkout."""
    source = Path(source).resolve()
    sys.path.insert(0, str(source))
    spec = importlib.util.spec_from_file_location('official_mm_preprocessing', source/'dataset/finetune_data_process.py')
    preprocessing = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(preprocessing)
    # Transformers >=4.40 calls get_vocab during base initialization. Upstream
    # assigns encoder later; seed it before calling the unchanged initializer.
    base = preprocessing.PolymerSmilesTokenizer
    class CompatibleTokenizer(base):
        def __init__(self, vocab_file, merges_file, **kwargs):
            self.encoder = json.loads(Path(vocab_file).read_text())
            super().__init__(vocab_file, merges_file, **kwargs)
    tokenizer = CompatibleTokenizer.from_pretrained(tokenizer_path, local_files_only=True, max_len=411)
    module = importlib.import_module('MMPolymer.models.MMPolymer')
    # Model construction requests roberta-base even though tokenizer has no
    # trainable weights. Inject the already verified local original tokenizer.
    from unittest.mock import patch
    from unicore.data import Dictionary
    dictionary = Dictionary.load(str(source/'dict.txt'))
    dictionary.add_symbol('[MASK]', is_special=True)
    args = SimpleNamespace(mode='train')
    with source_cwd(source), patch.object(module.PolymerSmilesTokenizer, 'from_pretrained', return_value=tokenizer):
        model = module.MMPolymerModel(args, dictionary)
    return preprocessing, tokenizer, dictionary, model

def prepare_records(frame, preprocessing, tokenizer, cache, provenance):
    cache = Path(cache)
    cache.mkdir(parents=True, exist_ok=True)
    records = []
    for row in frame.itertuples(index=False):
        identity = dict(provenance, smiles=row.smiles, row_index=int(row.row_index))
        key = hashlib.sha256(json.dumps(identity, sort_keys=True).encode()).hexdigest()
        path = cache/(key+'.pkl')
        if path.exists():
            with path.open('rb') as f:
                payload = pickle.load(f)
            if payload['provenance'] != identity:
                raise ValueError('Cache provenance mismatch')
            record = payload['record']
        else:
            try:
                record = restore_canonical_endpoints(preprocessing.inner_smi2coords((row.smiles, 0.)))
                if len(record['coordinates']) != 11:
                    raise ValueError('Expected eleven conformers')
                for i in range(11):
                    geometry(record, i, 42)
                encoded = tokenizer(row.smiles, add_special_tokens=True, max_length=411,
                                    return_token_type_ids=False, padding='max_length',
                                    truncation=True, return_attention_mask=True, return_tensors='pt')
                record['input_ids'] = encoded['input_ids'].flatten()
                record['attention_mask'] = encoded['attention_mask'].flatten()
            except Exception as exc:
                raise ValueError(f'Preprocessing failed for row_index={row.row_index}, smiles={row.smiles}: {exc}') from exc
            temp = path.with_suffix('.tmp')
            with temp.open('wb') as f:
                pickle.dump(dict(provenance=identity, record=record), f)
            os.replace(temp, path)
        records.append(record)
    return records

def tensor_batch(records, pairs, dictionary, device, seed):
    import torch
    items = []
    for row, conf in pairs:
        atoms, xyz = geometry(records[row], conf, seed + row)
        tokens = [dictionary.bos()] + [dictionary.index(a) for a in atoms] + [dictionary.eos()]
        xyz = np.pad(xyz, ((1,1),(0,0)))
        items.append((tokens, xyz, records[row]))
    n = int(math.ceil(max(len(item[0]) for item in items)/8)*8)
    b = len(items)
    tokens = torch.full((b,n), dictionary.pad(), dtype=torch.long)
    coords = torch.zeros((b,n,3))
    distance = torch.zeros((b,n,n))
    edges = torch.zeros((b,n,n), dtype=torch.long)
    for i, (tok, xyz, _) in enumerate(items):
        l = len(tok)
        t = torch.tensor(tok)
        tokens[i,:l] = t
        coords[i,:l] = torch.from_numpy(xyz)
        distance[i,:l,:l] = torch.cdist(coords[i,:l], coords[i,:l])
        edges[i,:l,:l] = t[:,None]*len(dictionary)+t[None,:]
    values = dict(src_tokens=tokens, src_coord=coords, src_distance=distance, src_edge_type=edges,
                  src_input_ids=torch.stack([item[2]['input_ids'] for item in items]),
                  src_attention_mask=torch.stack([item[2]['attention_mask'] for item in items]))
    return {k:v.to(device) for k,v in values.items()}

def predict(model, records, dictionary, args, mean, scale):
    import torch
    model.eval()
    pairs = [(i,c) for i in range(len(records)) for c in range(11)]
    result = []
    with torch.no_grad():
        for offset in range(0, len(pairs), args.batch_size):
            output = model(**tensor_batch(records, pairs[offset:offset+args.batch_size], dictionary, args.device, args.seed), classification_head_name='benchmark')[0]
            result.extend(output.flatten().cpu().tolist())
    return average_conformers(np.asarray(result)*scale+mean, len(records))

def parser():
    p = argparse.ArgumentParser(description=__doc__)
    for name in ('manifest', 'checkpoint', 'source-root', 'output', 'cache'):
        p.add_argument('--'+name, required=True)
    p.add_argument('--tokenizer', '--tokenizer-path', dest='tokenizer', default='roberta-base', help='Local tokenizer directory or locally cached roberta-base')
    for name, default in (('fold',None),('train-size',None),('epochs',50),('batch-size',4),('effective-batch-size',32),('seed',42),('threads',4)):
        p.add_argument('--'+name, type=int, default=default, required=default is None)
    p.add_argument('--learning-rate', type=float, default=1e-4)
    p.add_argument('--device', default='cpu')
    return p

def main(argv=None):
    args = parser().parse_args(argv)
    started = time.monotonic()
    adapter_sha256 = sha(__file__)
    shared_sha256 = sha(Path(__file__).resolve().parents[1]/'shared_benchmark.py')
    validate_options(args.epochs, args.batch_size, args.effective_batch_size)
    checkpoint = require_checkpoint(args.checkpoint).resolve()
    out = Path(args.output).resolve()
    if (out/'metrics.json').exists():
        raise FileExistsError('Completed output exists')
    import torch
    sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
    from shared_benchmark import load_split, write_run
    args.seed += args.fold
    torch.set_num_threads(args.threads)
    random.seed(args.seed)
    np.random.seed(args.seed)
    torch.manual_seed(args.seed)
    bundle = load_split(args.manifest, args.fold, args.train_size)
    preprocessing, tokenizer, dictionary, model = load_external(args.source_root, args.tokenizer)
    load_pretrained(model, checkpoint)
    print(json.dumps(dict(stage='pretrained_loaded', elapsed_seconds=time.monotonic()-started,
                          trainable_parameters=sum(p.numel() for p in model.parameters() if p.requires_grad))), flush=True)
    model = model.float().to(args.device)
    source = Path(args.source_root).resolve()
    source_hashes = {str(path.relative_to(source)):sha(path) for path in sorted(source.rglob('*'))
                     if path.is_file() and path.suffix in ('.py','.json','.txt') and '__pycache__' not in path.parts}
    tokenizer_root = Path(args.tokenizer).resolve()
    tokenizer_hashes = {str(path.relative_to(tokenizer_root)):sha(path) for path in sorted(tokenizer_root.rglob('*'))
                        if path.is_file() and path.suffix in ('.json','.txt') and '.cache' not in path.parts} if tokenizer_root.is_dir() else {}
    from importlib.metadata import version
    provenance = dict(canonical_sha256=bundle.canonical_sha256, source_revision=UPSTREAM_REVISION,
                      adapter_sha256=adapter_sha256, tokenizer_files=tokenizer_hashes, runtime_versions={p:version(p) for p in ('torch','numpy','rdkit','transformers')},
                      source_files=source_hashes, tokenizer_vocab_sha256=hashlib.sha256(json.dumps(tokenizer.get_vocab(),sort_keys=True).encode()).hexdigest(),
                      preprocessing_version=2, endpoint_mapping='canonical _smilesAtomOutputOrder correction')
    records = {}
    for split in ('train','val','test'):
        records[split] = prepare_records(getattr(bundle,split), preprocessing, tokenizer, args.cache, provenance)
        print(json.dumps(dict(stage='preprocessed', split=split, rows=len(records[split]),
                              elapsed_seconds=time.monotonic()-started)), flush=True)
    mean, scale = fit_scaler(bundle.train.target)
    target = torch.tensor((bundle.train.target.to_numpy()-mean)/scale, dtype=torch.float32, device=args.device)
    optimizer = torch.optim.Adam(model.parameters(), lr=args.learning_rate, betas=(.9,.99), eps=1e-6)
    out.mkdir(parents=True, exist_ok=True)
    best, history, best_epoch = float('inf'), [], None
    rng = np.random.RandomState(args.seed)
    for epoch in range(1,args.epochs+1):
        model.train()
        order = rng.permutation(len(target))
        # Each accumulation group averages by its actual molecule count,
        # including the last short group.
        for start in range(0,len(order),args.effective_batch_size):
            group = order[start:start+args.effective_batch_size]
            optimizer.zero_grad(set_to_none=True)
            for offset in range(0,len(group),args.batch_size):
                rows = group[offset:offset+args.batch_size]
                pairs = [(int(i), int(rng.randint(11))) for i in rows]
                output = model(**tensor_batch(records['train'],pairs,dictionary,args.device,args.seed), classification_head_name='benchmark')[0].flatten()
                loss = torch.nn.functional.mse_loss(output,target[rows],reduction='sum')/len(group)
                if not torch.isfinite(loss):
                    raise ValueError('Nonfinite training loss')
                loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(),1.)
            optimizer.step()
            print(json.dumps(dict(stage='train_update',epoch=epoch,rows=min(start+len(group),len(order)),
                                  total_rows=len(order),elapsed_seconds=time.monotonic()-started)),flush=True)
        val = predict(model,records['val'],dictionary,args,mean,scale)
        rmse = float(np.sqrt(np.mean((val-bundle.val.target.to_numpy())**2)))
        if not np.isfinite(rmse):
            raise ValueError('Nonfinite validation RMSE')
        history.append(dict(epoch=epoch,val_rmse=rmse,elapsed_seconds=time.monotonic()-started))
        (out/'history.json').write_text(json.dumps(history,indent=2)+'\n')
        print(json.dumps(history[-1]),flush=True)
        if rmse < best:
            best, best_epoch = rmse, epoch
            torch.save(model.state_dict(),out/'best.pt')
    model.load_state_dict(torch.load(out/'best.pt',map_location=args.device,weights_only=True))
    predictions = {}
    for split in records:
        predictions[split] = predict(model,records[split],dictionary,args,mean,scale)
        print(json.dumps(dict(stage='predicted',split=split,rows=len(predictions[split]),
                              elapsed_seconds=time.monotonic()-started)),flush=True)
    config = dict(vars(args), checkpoint_sha256=sha(checkpoint),source_revision=UPSTREAM_REVISION,
                  adapter_sha256=adapter_sha256,shared_sha256=shared_sha256,tokenizer_files=tokenizer_hashes,
                  runtime_versions=provenance['runtime_versions'],
                  source_files=source_hashes, full_finetuning=True,precision='float32',loss='train-standardized MSE',
                  target_mean=mean,target_scale=scale,best_epoch=best_epoch,best_val_rmse=best,conformers=11,
                  preprocessing=provenance, optimizer='Adam betas=(0.9,0.99) eps=1e-6; constant LR; clip_norm=1.0')
    write_run(out,'MMPolymer',bundle,predictions,config)

if __name__ == '__main__':
    main()
