"""Strict published-index loading and row-preserving benchmark evaluation."""
from dataclasses import dataclass
import hashlib
import json
import os
from pathlib import Path
import tempfile

import numpy as np
import pandas as pd
from sklearn.metrics import r2_score


@dataclass
class SplitBundle:
    train: pd.DataFrame
    val: pd.DataFrame
    test: pd.DataFrame
    target_column: str
    manifest: dict
    canonical_sha256: str
    fold: int
    train_size: int
    manifest_path: str
    indices_sha256: str


def _sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def _fingerprint(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False).encode()).hexdigest()


def load_split(manifest_path, fold, train_size):
    """Load exactly train_pool[:train_size], val, test, rejecting corruption."""
    path = Path(manifest_path).resolve()
    manifest = json.loads(path.read_text())
    if type(fold) is not int or type(train_size) is not int or train_size <= 0 or train_size not in manifest['train_sizes']:
        raise ValueError('Unsupported fold or train_size')
    folds = manifest['folds']
    matching = [f for f in folds if f['fold'] == fold]
    if len(matching) != 1 or len(folds) != manifest['num_folds']:
        raise ValueError('Invalid configured folds')
    entry = matching[0]
    roots = [p.parent for p in path.parents if p.name == 'scaling_indices' and p.parent.name == 'Datasets']
    if len(roots) != 1:
        raise ValueError('Manifest must be beneath Datasets/scaling_indices')
    root = roots[0]
    source = (root / manifest['canonical_source']).resolve()
    if not source.is_relative_to(root):
        raise ValueError('Canonical source escapes Datasets')
    sha = _sha(source)
    if sha != manifest['canonical_sha256']:
        raise ValueError('Canonical SHA-256 mismatch')
    frame = pd.read_csv(source)
    target_column = manifest['target_column']
    if len(frame) != manifest['n_rows'] or 'smiles' not in frame or target_column not in frame:
        raise ValueError('Canonical schema or row count mismatch')
    labels = pd.to_numeric(frame[target_column], errors='raise').to_numpy(dtype=float)
    if not np.isfinite(labels).all():
        raise ValueError('Nonfinite canonical labels')
    if frame.smiles.isna().any() or not frame.smiles.map(lambda x: isinstance(x, str) and bool(x.strip())).all():
        raise ValueError('Missing or invalid smiles')
    indices_path = (path.parent / entry['indices_file']).resolve()
    if not indices_path.is_relative_to(path.parent):
        raise ValueError('Indices file escapes manifest directory')
    indices_sha = _sha(indices_path)
    parts = {}
    with np.load(indices_path, allow_pickle=False) as data:
        for name in ('train_pool', 'val', 'test'):
            values = data[name]
            if values.ndim != 1 or values.dtype.kind not in 'iu' or len(values) != entry['n_' + name]:
                raise ValueError('Invalid partition indices or counts: ' + name)
            if len(values) == 0 or (values < 0).any() or (values >= len(frame)).any():
                raise ValueError('Empty or out-of-range partition: ' + name)
            parts[name] = values.copy()
    all_indices = np.concatenate(list(parts.values()))
    if len(all_indices) != len(frame) or len(np.unique(all_indices)) != len(frame):
        raise ValueError('Partitions overlap, duplicate rows, or omit rows')
    if train_size > len(parts['train_pool']):
        raise ValueError('train_size exceeds train pool')
    def select(indices):
        return pd.DataFrame({'row_index': indices, 'smiles': frame.iloc[indices].smiles.to_numpy(), 'target': labels[indices]})
    return SplitBundle(select(parts['train_pool'][:train_size]), select(parts['val']), select(parts['test']), target_column, manifest, sha, fold, train_size, str(path), indices_sha)


def write_run(output_dir, model_name, bundle, predictions, config):
    """Publish predictions first and atomic completion metadata last.

    Constant targets or fewer than two rows fail because R2 is undefined.
    Existing completion metadata is never overwritten. Partial runs may retry.
    """
    out = Path(output_dir)
    if (out / 'metrics.json').exists():
        raise FileExistsError('Completed run already exists: ' + str(out))
    if set(predictions) != {'train', 'val', 'test'}:
        raise ValueError('Predictions must include exactly train, val, test')
    metrics, tables, row_hashes = {}, {}, {}
    for split in ('train', 'val', 'test'):
        frame = getattr(bundle, split)
        true = frame.target.to_numpy(dtype=float)
        pred = np.asarray(predictions[split], dtype=float)
        if pred.ndim != 1 or len(pred) != len(true) or not np.isfinite(pred).all() or not np.isfinite(true).all():
            raise ValueError('Invalid labels or predictions: ' + split)
        variance = float(np.var(true, ddof=0))
        if len(true) < 2 or variance == 0:
            raise ValueError('R2 undefined for constant or singleton target: ' + split)
        with np.errstate(over='ignore', invalid='ignore'):
            mse = float(np.mean((true - pred) ** 2))
            direct = float(1 - mse / variance)
            sklearn_r2 = float(r2_score(true, pred))
        if not np.isfinite([mse, direct, sklearn_r2]).all() or not np.isclose(direct, sklearn_r2, rtol=1e-10, atol=1e-12):
            raise ValueError('Nonfinite metrics or R2 formula cross-check failed')
        metrics[split] = dict(split=split, rmse=float(np.sqrt(mse)), mae=float(np.mean(np.abs(true - pred))), mse=mse, r2=direct, r2_sklearn=sklearn_r2, target_variance=variance, n_samples=len(true))
        tables[split] = pd.DataFrame({'row_index': frame.row_index.to_numpy(), 'y_true': true, 'y_pred': pred})
        row_hashes[split] = _fingerprint(frame.row_index.tolist())
    provenance = dict(canonical_sha256=bundle.canonical_sha256, indices_sha256=bundle.indices_sha256, manifest_sha256=_fingerprint(bundle.manifest), fold=bundle.fold, train_size=bundle.train_size, row_indices_sha256=row_hashes)
    result = dict(model=model_name, status='complete', schema_version=1, seed=config.get('seed', bundle.manifest.get('seed')), target_columns=[bundle.target_column], fold=bundle.fold, train_size=bundle.train_size, config=config, config_fingerprint=_fingerprint(config), source_fingerprint=_fingerprint(provenance), provenance=provenance, metrics=metrics)
    result['run_fingerprint'] = _fingerprint(dict(model=model_name, config=config, provenance=provenance))
    serialized = json.dumps(result, indent=2, allow_nan=False) + '\n'
    out.mkdir(parents=True, exist_ok=True)
    # Exclusive lock prevents concurrent writers from racing completion checks.
    lock = out / '.write_run.lock'
    fd = os.open(lock, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
    os.close(fd)
    try:
        if (out / 'metrics.json').exists():
            raise FileExistsError('Completed run already exists: ' + str(out))
        with tempfile.TemporaryDirectory(prefix='.run-', dir=out) as stage:
            stage = Path(stage)
            for split, table in tables.items():
                table.to_csv(stage / f'preds_{split}.csv', index=False)
            (stage / 'metrics.json').write_text(serialized)
            for split in tables:
                os.replace(stage / f'preds_{split}.csv', out / f'preds_{split}.csv')
            os.replace(stage / 'metrics.json', out / 'metrics.json')
    finally:
        lock.unlink()
    return result
