"""Recover R2 from published per-fold squared errors and verified target arrays.

Usage: python recover_r2.py REPOSITORY OUTPUT_DIRECTORY
Requires numpy and pandas. Run OMers_convert_jsonl.py with RDKit 2025.9.6 first.
No model training or prediction recovery is performed.
"""
import sys, json, hashlib
from pathlib import Path
import numpy as np
import pandas as pd

repo, out = map(Path, sys.argv[1:])
out.mkdir(parents=True, exist_ok=True)
detail = pd.read_csv(repo / 'scaling_results/all/scaling_results_detailed.csv')
aggregate = pd.read_csv(repo / 'scaling_results/all/scaling_results_aggregate.csv')
cache, audit = {}, []
for experiment in detail.experiment.unique():
    base = repo / 'Datasets/scaling_indices' / experiment
    manifest = json.loads((base / 'manifest.json').read_text())
    source = repo / 'Datasets' / manifest['canonical_source']
    digest = hashlib.sha256(source.read_bytes()).hexdigest()
    assert digest == manifest['canonical_sha256'], f'Checksum mismatch: {source}'
    frame = pd.read_csv(source)
    assert len(frame) == manifest['n_rows']
    y = frame[manifest['target_column']].to_numpy(dtype=float)
    assert np.isfinite(y).all()
    folds = {}
    for fold in manifest['folds']:
        with np.load(base / fold['indices_file'], allow_pickle=False) as z:
            indices = {k: z[k].copy() for k in z.files}
        combined = np.concatenate(list(indices.values()))
        assert np.array_equal(np.sort(combined), np.arange(len(y)))
        for key in ['train_pool', 'val', 'test']:
            assert len(indices[key]) == fold['n_' + key]
        folds[fold['fold']] = indices
    cache[experiment] = y, folds
    audit.append(dict(experiment=experiment, canonical_sha256=digest,
                      rows=len(y), folds=len(folds), checksum_verified=True))

records = []
for row in detail.to_dict('records'):
    y, folds = cache[row['experiment']]
    indices = folds[int(row['fold'])]
    idx = indices['train_pool'][:int(row['train_size'])] if row['split'] == 'train' else indices[row['split']]
    target = y[idx]
    # polyBERT's ArrayDataset stores labels in float32; its metric function
    # subsequently casts them to float64. Preserve that evaluation convention.
    if row['model'] == 'polyBERT':
        target = target.astype(np.float32).astype(np.float64)
    if pd.notna(row['n_samples']):
        assert int(row['n_samples']) == len(target)
    variance = np.var(target, ddof=0)
    assert variance > 0
    mse = row['mse'] if pd.notna(row['mse']) else row['rmse'] ** 2
    assert np.isclose(mse, row['rmse'] ** 2, rtol=1e-10)
    row.update(r2=1-mse/variance, target_variance_ddof0=variance,
               n_samples_verified=len(target), mse_used=mse,
               r2_method='published_fold_error_and_verified_targets',
               target_precision='float32_then_float64' if row['model']=='polyBERT' else 'float64')
    records.append(row)
result = pd.DataFrame(records)
keys = ['experiment','dataset','quantity','polymer_type','model','train_size','split']
stats = result.groupby(keys, dropna=False).agg(
    r2_mean=('r2','mean'), r2_std=('r2',lambda x: np.std(x,ddof=0)),
    r2_n_folds=('fold','nunique')).reset_index()
merged = aggregate.merge(stats, on=keys, how='left', validate='one_to_one')
assert len(merged) == len(aggregate)
assert merged.r2_mean.notna().all()
assert (merged.n_folds == merged.r2_n_folds).all()
assert not result.duplicated(keys+['fold']).any()
# Independently reconstruct published RMSE aggregates as a grouping check.
check = result.groupby(keys,dropna=False).rmse.agg(['mean',lambda x:np.std(x,ddof=0)]).reset_index()
check = aggregate.merge(check,on=keys,validate='one_to_one')
assert np.allclose(check.rmse_mean,check['mean'],rtol=1e-12,atol=1e-12)
assert np.allclose(check.rmse_std,check['<lambda_0>'],rtol=1e-12,atol=1e-12)
result.to_csv(out/'scaling_results_detailed_with_r2.csv',index=False)
merged.to_csv(out/'scaling_results_aggregate_with_r2.csv',index=False)
test = merged[merged.split=='test'].copy()
test.to_csv(out/'test_r2.csv',index=False)
audit_result = dict(source_commit='83655bc25901a8cabe3a1e5474b7ec26f01b919f',
    method='Algebraic recovery from published per-fold metrics; not model retraining',
    detailed_rows=len(result), aggregate_rows=len(merged), test_groups=len(test),
    canonical_sources=audit, all_sample_counts_match=True,
    all_published_rmse_aggregates_match=True,
    limitations='Original predictions are not public; precision is limited by published errors and documented evaluation conventions.')
(out/'verification.json').write_text(json.dumps(audit_result,indent=2)+'\n')
print(json.dumps({k:v for k,v in audit_result.items() if k!='canonical_sources'},indent=2))
print(test[test.experiment.str.startswith('PolyMetriX')][['model','train_size','r2_mean','r2_std']].to_string(index=False))
